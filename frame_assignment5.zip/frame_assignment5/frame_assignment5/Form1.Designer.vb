﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWeight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lblWeight = New System.Windows.Forms.Label()
        Me.grpPlanetType = New System.Windows.Forms.GroupBox()
        Me.radMars = New System.Windows.Forms.RadioButton()
        Me.radMoon = New System.Windows.Forms.RadioButton()
        Me.txtWeight = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lbl = New System.Windows.Forms.Label()
        Me.lblCalculatedWeight = New System.Windows.Forms.Label()
        Me.lblKGweight = New System.Windows.Forms.Label()
        Me.lblTotalKG = New System.Windows.Forms.Label()
        Me.grpPlanetType.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Location = New System.Drawing.Point(104, 29)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(174, 13)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Weight on Moon or Mars Calculator"
        '
        'lblWeight
        '
        Me.lblWeight.AutoSize = True
        Me.lblWeight.Location = New System.Drawing.Point(104, 66)
        Me.lblWeight.Name = "lblWeight"
        Me.lblWeight.Size = New System.Drawing.Size(72, 13)
        Me.lblWeight.TabIndex = 1
        Me.lblWeight.Text = "Enter Weight:"
        '
        'grpPlanetType
        '
        Me.grpPlanetType.Controls.Add(Me.radMars)
        Me.grpPlanetType.Controls.Add(Me.radMoon)
        Me.grpPlanetType.Location = New System.Drawing.Point(107, 114)
        Me.grpPlanetType.Name = "grpPlanetType"
        Me.grpPlanetType.Size = New System.Drawing.Size(200, 100)
        Me.grpPlanetType.TabIndex = 2
        Me.grpPlanetType.TabStop = False
        Me.grpPlanetType.Text = "Select Planet"
        '
        'radMars
        '
        Me.radMars.AutoSize = True
        Me.radMars.Location = New System.Drawing.Point(23, 69)
        Me.radMars.Name = "radMars"
        Me.radMars.Size = New System.Drawing.Size(48, 17)
        Me.radMars.TabIndex = 1
        Me.radMars.TabStop = True
        Me.radMars.Text = "Mars"
        Me.radMars.UseVisualStyleBackColor = True
        '
        'radMoon
        '
        Me.radMoon.AutoSize = True
        Me.radMoon.Location = New System.Drawing.Point(23, 33)
        Me.radMoon.Name = "radMoon"
        Me.radMoon.Size = New System.Drawing.Size(52, 17)
        Me.radMoon.TabIndex = 0
        Me.radMoon.TabStop = True
        Me.radMoon.Text = "Moon"
        Me.radMoon.UseVisualStyleBackColor = True
        '
        'txtWeight
        '
        Me.txtWeight.Location = New System.Drawing.Point(209, 66)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Size = New System.Drawing.Size(100, 20)
        Me.txtWeight.TabIndex = 3
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(107, 326)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 4
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(234, 326)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lbl
        '
        Me.lbl.AutoSize = True
        Me.lbl.Location = New System.Drawing.Point(104, 249)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(44, 13)
        Me.lbl.TabIndex = 6
        Me.lbl.Text = "Weight:"
        '
        'lblCalculatedWeight
        '
        Me.lblCalculatedWeight.AutoSize = True
        Me.lblCalculatedWeight.Location = New System.Drawing.Point(206, 249)
        Me.lblCalculatedWeight.Name = "lblCalculatedWeight"
        Me.lblCalculatedWeight.Size = New System.Drawing.Size(25, 13)
        Me.lblCalculatedWeight.TabIndex = 7
        Me.lblCalculatedWeight.Text = "000"
        '
        'lblKGweight
        '
        Me.lblKGweight.AutoSize = True
        Me.lblKGweight.Location = New System.Drawing.Point(107, 282)
        Me.lblKGweight.Name = "lblKGweight"
        Me.lblKGweight.Size = New System.Drawing.Size(67, 13)
        Me.lblKGweight.TabIndex = 8
        Me.lblKGweight.Text = "Weight in kg"
        '
        'lblTotalKG
        '
        Me.lblTotalKG.AutoSize = True
        Me.lblTotalKG.Location = New System.Drawing.Point(206, 282)
        Me.lblTotalKG.Name = "lblTotalKG"
        Me.lblTotalKG.Size = New System.Drawing.Size(25, 13)
        Me.lblTotalKG.TabIndex = 9
        Me.lblTotalKG.Text = "000"
        '
        'lblCalWeight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(407, 385)
        Me.Controls.Add(Me.lblTotalKG)
        Me.Controls.Add(Me.lblKGweight)
        Me.Controls.Add(Me.lblCalculatedWeight)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtWeight)
        Me.Controls.Add(Me.grpPlanetType)
        Me.Controls.Add(Me.lblWeight)
        Me.Controls.Add(Me.lblHeading)
        Me.Name = "lblCalWeight"
        Me.Text = "Weight Calclator"
        Me.grpPlanetType.ResumeLayout(False)
        Me.grpPlanetType.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeading As Label
    Friend WithEvents lblWeight As Label
    Friend WithEvents grpPlanetType As GroupBox
    Friend WithEvents radMoon As RadioButton
    Friend WithEvents radMars As RadioButton
    Friend WithEvents txtWeight As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents lbl As Label
    Friend WithEvents lblCalculatedWeight As Label
    Friend WithEvents lblKGweight As Label
    Friend WithEvents lblTotalKG As Label
End Class
