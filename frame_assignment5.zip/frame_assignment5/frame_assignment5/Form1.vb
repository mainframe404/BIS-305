﻿' Program Name: Weight on Moon an Mars Calculator Application 
' Author:       Allyson Frame
' Date:         October 3, 2017
' Purpose:      This Windows application computes the estimated weight 
'               on the moon and mars
'
Option Strict On

Public Class frmWeight
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' The btnCalculate event handler calculates the estimated weight of  
        ' planet weight based on the weight entered and selected planet.

        Dim decMoon As Decimal = 0.166D
        Dim decMars As Decimal = 0.377D
        Dim decPlanetWeight As Decimal
        Dim decWeight As Decimal
        Dim decKill As Decimal = 0.454D
        Dim decPlanetKill As Decimal


        'did user enter numeric value?

        If IsNumeric(txtWeight.Text) Then
            decWeight = Convert.ToDecimal(txtWeight.Text)

            If decWeight > 0 Then
                'Calculates weight
                If radMoon.Checked Then
                    decPlanetWeight = decWeight * decMoon
                    decPlanetKill = (decWeight * decKill) * decMoon
                ElseIf radMars.Checked Then
                    decPlanetWeight = decWeight * decMars
                    decPlanetKill = (decWeight * decKill) * decMars
                End If

                lblCalculatedWeight.Text = decPlanetWeight.ToString("C")
                lblTotalKG.Text = decPlanetKill.ToString("C")

            Else
                ' Display error message if negative value
                MsgBox("You enterd " & decWeight.ToString() & ". Enter a positive number", , "Input Error")
                txtWeight.Text = " "
                txtWeight.Focus()
            End If
            ' Display error message if user entered a nonnumeric value
            MsgBox("Enter the Square Footage of Flooring", , "Input Error")
            txtWeight.Text = ""
            txtWeight.Focus()
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' This event handler is executed when the user taps or clicks the Clear button.

        txtWeight.Clear()
        lblCalculatedWeight.Text = ""
        radMoon.Checked = True
        radMars.Checked = False
        txtWeight.Focus()
    End Sub

    Private Sub frmWeight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' This event handler is executed when the form is loaded at the start of 
        ' the program

        txtWeight.Focus()
        lblCalculatedWeight.Text = " "
    End Sub


End Class
