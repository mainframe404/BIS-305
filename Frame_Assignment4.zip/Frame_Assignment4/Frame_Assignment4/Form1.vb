﻿' Program:  Income Tax Calculator
' Author:   Allyson Frame
' Date:     September 26, 2017
' Purpose:  This application calculates and displays 
'           the taxes for a given yearly income
Option Strict On

Public Class frmTax

    Const FICATax As Double = 0.0765
    Const FederalTax As Double = 0.22
    Const IncomeTax As Double = 0.03

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim strYearlyIncome As String
        Dim intYearlyIncome As Double
        Dim totalFICATax As Double
        Dim totalFederalTax As Double
        Dim totalStateTax As Double
        Dim totalTax As Double
        Dim totalNetPay As Double

        strYearlyIncome = txtYearlyIncome.Text
        intYearlyIncome = Convert.ToDouble(strYearlyIncome)

        totalFICATax = intYearlyIncome * FICATax
        lblFICATax.Text = totalFICATax.ToString("C")

        totalFederalTax = intYearlyIncome * FederalTax
        lblFederalTax.Text = totalFederalTax.ToString("C")

        totalStateTax = intYearlyIncome * IncomeTax
        lblStateTax.Text = totalStateTax.ToString("C")

        totalTax = totalFICATax + totalStateTax + totalFederalTax

        totalNetPay = intYearlyIncome - totalTax
        lblTotalNetPay.Text = totalTax.ToString("C")



    End Sub

    Private Sub btnClear_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnClear.Click
        ' This event handler is executed when the user taps or clicks the
        ' Clear button. It clears the number of yearly income text box.
        ' Then, it sets the focus on the txtYearlyIncome Textbox object.

        txtYearlyIncome.Clear()
        lblFICATax.Text = ""
        lblFederalTax.Text = ""
        lblStateTax.Text = ""
        lblTotalNetPay.Text = ""
        txtYearlyIncome.Focus()

    End Sub

    Private Sub btnExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bntExit.Click
        ' Close the window and terminate the application

        Close()

    End Sub
End Class
