﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTax
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtYearlyIncome = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.bntExit = New System.Windows.Forms.Button()
        Me.lblTotalFICATax = New System.Windows.Forms.Label()
        Me.lblFICATax = New System.Windows.Forms.Label()
        Me.lblTotalFederalTax = New System.Windows.Forms.Label()
        Me.lblFederalTax = New System.Windows.Forms.Label()
        Me.lblTotalStateTax = New System.Windows.Forms.Label()
        Me.lblStateTax = New System.Windows.Forms.Label()
        Me.lnlNetPay = New System.Windows.Forms.Label()
        Me.lblTotalNetPay = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtYearlyIncome
        '
        Me.txtYearlyIncome.Location = New System.Drawing.Point(175, 62)
        Me.txtYearlyIncome.Name = "txtYearlyIncome"
        Me.txtYearlyIncome.Size = New System.Drawing.Size(69, 20)
        Me.txtYearlyIncome.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(68, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(113, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Income Tax Calculator"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(134, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Please Enter yearly income"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(49, 266)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calulate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.Location = New System.Drawing.Point(187, 266)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'bntExit
        '
        Me.bntExit.Location = New System.Drawing.Point(307, 266)
        Me.bntExit.Name = "bntExit"
        Me.bntExit.Size = New System.Drawing.Size(75, 23)
        Me.bntExit.TabIndex = 5
        Me.bntExit.Text = "Exit"
        Me.bntExit.UseVisualStyleBackColor = True
        '
        'lblTotalFICATax
        '
        Me.lblTotalFICATax.AutoSize = True
        Me.lblTotalFICATax.Location = New System.Drawing.Point(15, 106)
        Me.lblTotalFICATax.Name = "lblTotalFICATax"
        Me.lblTotalFICATax.Size = New System.Drawing.Size(78, 13)
        Me.lblTotalFICATax.TabIndex = 6
        Me.lblTotalFICATax.Text = "Total FICA Tax"
        '
        'lblFICATax
        '
        Me.lblFICATax.AutoSize = True
        Me.lblFICATax.Location = New System.Drawing.Point(141, 106)
        Me.lblFICATax.Name = "lblFICATax"
        Me.lblFICATax.Size = New System.Drawing.Size(40, 13)
        Me.lblFICATax.TabIndex = 7
        Me.lblFICATax.Text = "$88.88"
        '
        'lblTotalFederalTax
        '
        Me.lblTotalFederalTax.AutoSize = True
        Me.lblTotalFederalTax.Location = New System.Drawing.Point(12, 141)
        Me.lblTotalFederalTax.Name = "lblTotalFederalTax"
        Me.lblTotalFederalTax.Size = New System.Drawing.Size(90, 13)
        Me.lblTotalFederalTax.TabIndex = 8
        Me.lblTotalFederalTax.Text = "Total Federal Tax"
        '
        'lblFederalTax
        '
        Me.lblFederalTax.AutoSize = True
        Me.lblFederalTax.Location = New System.Drawing.Point(142, 141)
        Me.lblFederalTax.Name = "lblFederalTax"
        Me.lblFederalTax.Size = New System.Drawing.Size(40, 13)
        Me.lblFederalTax.TabIndex = 9
        Me.lblFederalTax.Text = "$88.88"
        '
        'lblTotalStateTax
        '
        Me.lblTotalStateTax.AutoSize = True
        Me.lblTotalStateTax.Location = New System.Drawing.Point(12, 172)
        Me.lblTotalStateTax.Name = "lblTotalStateTax"
        Me.lblTotalStateTax.Size = New System.Drawing.Size(118, 13)
        Me.lblTotalStateTax.TabIndex = 10
        Me.lblTotalStateTax.Text = "Total State Income Tax"
        '
        'lblStateTax
        '
        Me.lblStateTax.AutoSize = True
        Me.lblStateTax.Location = New System.Drawing.Point(142, 172)
        Me.lblStateTax.Name = "lblStateTax"
        Me.lblStateTax.Size = New System.Drawing.Size(40, 13)
        Me.lblStateTax.TabIndex = 11
        Me.lblStateTax.Text = "$88.88"
        '
        'lnlNetPay
        '
        Me.lnlNetPay.AutoSize = True
        Me.lnlNetPay.Location = New System.Drawing.Point(15, 201)
        Me.lnlNetPay.Name = "lnlNetPay"
        Me.lnlNetPay.Size = New System.Drawing.Size(45, 13)
        Me.lnlNetPay.TabIndex = 12
        Me.lnlNetPay.Text = "Net Pay"
        '
        'lblTotalNetPay
        '
        Me.lblTotalNetPay.AutoSize = True
        Me.lblTotalNetPay.Location = New System.Drawing.Point(142, 201)
        Me.lblTotalNetPay.Name = "lblTotalNetPay"
        Me.lblTotalNetPay.Size = New System.Drawing.Size(40, 13)
        Me.lblTotalNetPay.TabIndex = 13
        Me.lblTotalNetPay.Text = "$88.88"
        '
        'frmTax
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(434, 461)
        Me.Controls.Add(Me.lblTotalNetPay)
        Me.Controls.Add(Me.lnlNetPay)
        Me.Controls.Add(Me.lblStateTax)
        Me.Controls.Add(Me.lblTotalStateTax)
        Me.Controls.Add(Me.lblFederalTax)
        Me.Controls.Add(Me.lblTotalFederalTax)
        Me.Controls.Add(Me.lblFICATax)
        Me.Controls.Add(Me.lblTotalFICATax)
        Me.Controls.Add(Me.bntExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtYearlyIncome)
        Me.Name = "frmTax"
        Me.Text = "Income Tax Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtYearlyIncome As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents bntExit As Button
    Friend WithEvents lblTotalFICATax As Label
    Friend WithEvents lblFICATax As Label
    Friend WithEvents lblTotalFederalTax As Label
    Friend WithEvents lblFederalTax As Label
    Friend WithEvents lblTotalStateTax As Label
    Friend WithEvents lblStateTax As Label
    Friend WithEvents lnlNetPay As Label
    Friend WithEvents lblTotalNetPay As Label
End Class
