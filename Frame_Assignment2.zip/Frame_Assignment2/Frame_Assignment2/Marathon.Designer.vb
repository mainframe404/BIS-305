﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Marathon
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.allRunners = New System.Windows.Forms.Label()
        Me.MarathonPic = New System.Windows.Forms.PictureBox()
        Me.Info = New System.Windows.Forms.Button()
        Me.ExitWindow = New System.Windows.Forms.Button()
        Me.May = New System.Windows.Forms.Label()
        Me.Place = New System.Windows.Forms.Label()
        Me.Start = New System.Windows.Forms.Label()
        CType(Me.MarathonPic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'allRunners
        '
        Me.allRunners.AutoSize = True
        Me.allRunners.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.allRunners.Location = New System.Drawing.Point(12, 36)
        Me.allRunners.Name = "allRunners"
        Me.allRunners.Size = New System.Drawing.Size(254, 13)
        Me.allRunners.TabIndex = 0
        Me.allRunners.Text = "Full and half marathon runners are welcome"
        '
        'MarathonPic
        '
        Me.MarathonPic.Enabled = False
        Me.MarathonPic.Image = Global.Frame_Assignment2.My.Resources.Resources.Marathon
        Me.MarathonPic.Location = New System.Drawing.Point(68, 62)
        Me.MarathonPic.Name = "MarathonPic"
        Me.MarathonPic.Size = New System.Drawing.Size(124, 87)
        Me.MarathonPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MarathonPic.TabIndex = 1
        Me.MarathonPic.TabStop = False
        '
        'Info
        '
        Me.Info.Location = New System.Drawing.Point(15, 155)
        Me.Info.Name = "Info"
        Me.Info.Size = New System.Drawing.Size(75, 23)
        Me.Info.TabIndex = 2
        Me.Info.Text = "View Date"
        Me.Info.UseVisualStyleBackColor = True
        '
        'ExitWindow
        '
        Me.ExitWindow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ExitWindow.Location = New System.Drawing.Point(191, 155)
        Me.ExitWindow.Name = "ExitWindow"
        Me.ExitWindow.Size = New System.Drawing.Size(75, 23)
        Me.ExitWindow.TabIndex = 3
        Me.ExitWindow.Text = "Exit Window"
        Me.ExitWindow.UseVisualStyleBackColor = True
        '
        'May
        '
        Me.May.AutoSize = True
        Me.May.Location = New System.Drawing.Point(87, 181)
        Me.May.Name = "May"
        Me.May.Size = New System.Drawing.Size(81, 13)
        Me.May.TabIndex = 4
        Me.May.Text = "May 30th, 2017"
        Me.May.Visible = False
        '
        'Place
        '
        Me.Place.AutoSize = True
        Me.Place.Location = New System.Drawing.Point(90, 198)
        Me.Place.Name = "Place"
        Me.Place.Size = New System.Drawing.Size(57, 13)
        Me.Place.TabIndex = 5
        Me.Place.Text = "Ryan Park"
        Me.Place.Visible = False
        '
        'Start
        '
        Me.Start.AutoSize = True
        Me.Start.Location = New System.Drawing.Point(90, 215)
        Me.Start.Name = "Start"
        Me.Start.Size = New System.Drawing.Size(104, 13)
        Me.Start.TabIndex = 6
        Me.Start.Text = "Start Time: 8:00 AM "
        Me.Start.Visible = False
        '
        'Marathon
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Start)
        Me.Controls.Add(Me.Place)
        Me.Controls.Add(Me.May)
        Me.Controls.Add(Me.ExitWindow)
        Me.Controls.Add(Me.Info)
        Me.Controls.Add(Me.MarathonPic)
        Me.Controls.Add(Me.allRunners)
        Me.Name = "Marathon"
        Me.Text = "Fall Marathon"
        CType(Me.MarathonPic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents allRunners As Label
    Friend WithEvents MarathonPic As PictureBox
    Friend WithEvents Info As Button
    Friend WithEvents ExitWindow As Button
    Friend WithEvents May As Label
    Friend WithEvents Place As Label
    Friend WithEvents Start As Label
End Class
