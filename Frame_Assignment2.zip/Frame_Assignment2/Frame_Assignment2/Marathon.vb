﻿' Program Name: Marathon 

Public Class Marathon
    Private Sub Info_Click(sender As Object, e As EventArgs) Handles Info.Click
        ' This code is executed when the user taps or clicks the
        ' View Date button. 

        MarathonPic.Visible = True
        Info.Enabled = False
        ExitWindow.Enabled = True
        May.Visible = True
        Place.Visible = True
        Start.Visible = True
    End Sub

    Private Sub ExitWindow_Click(sender As Object, e As EventArgs) Handles ExitWindow.Click
        ' This code is executed when the user taps or clicks the
        ' This will close the window 

        Close()

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub
End Class
