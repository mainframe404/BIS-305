﻿' Program Name: Penny a Day or Nickel a Day
' Author:       Allyson Frame
' Date:         October 20, 2017
' Purpose:      To calculate the amount of pay for the pay period 

Option Strict On

Public Class frmPayDay

    Private Sub btnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalculate.Click

        Dim intNumberOfDays As Integer
        Const decPenny As Decimal = 0.01D
        Const decNickel As Decimal = 0.05D
        Dim decAmountDisplay As Decimal
        Dim decChosenPay As Decimal
        Const decDouble As Decimal = 2D
        Dim decTotalOfDayPay As Decimal

        'This code validates the user input as numeric and a positive number.

        If IsNumeric(Me.txtNumberOfDays.Text) Then
            intNumberOfDays = Convert.ToInt32(Me.txtNumberOfDays.Text)
            If intNumberOfDays > 0 Then

                'This code will extract what the user has chosen as their first day pay rate.

                If radPenny.Checked = True Then
                    decChosenPay = decPenny
                ElseIf radNickel.Checked = True Then
                    decChosenPay = decNickel
                End If

                'This code will double the pay rate each day after the first day

                If intNumberOfDays > 1 Then
                    For i As Integer = 0 To intNumberOfDays Step i + 1
                        Me.lstDisplay.Items.Add(decChosenPay)
                        decChosenPay += decTotalOfDayPay
                        decAmountDisplay = decChosenPay * decDouble
                        decAmountDisplay = intNumberOfDays * decChosenPay
                        Me.lblAmountDisplay.Text = decAmountDisplay.ToString("C")
                        Me.lblAmountDisplay.Visible = True
                    Next
                Else
                    MessageBox.Show("You entered a negative value, please enter a number greater than zero!", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.txtNumberOfDays.Clear()
                    Me.txtNumberOfDays.Focus()
                End If
            Else
                'Display MessageBox if negative or nonnumeric value is entered

                MessageBox.Show("You entered an invalid value, please try again!", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.txtNumberOfDays.Clear()
                Me.radNickel.Checked = False
                Me.radPenny.Checked = True
                Me.lblAmountDisplay.Visible = False
                Me.btnCalculate.Enabled = True
            End If
        End If

    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        ' The mnuClear click event clears the ListBox object and hides 
        ' the average weight loss label. It also enables the Weight Loss button

        'txtDays.Items.Clear()
        lblAmountDisplay.Visible = False
        btnCalculate.Enabled = True

    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        ' The mnuExit click event closes the window and exits the application

        Close()
    End Sub
End Class
