﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPayDay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radPenny = New System.Windows.Forms.RadioButton()
        Me.radNickel = New System.Windows.Forms.RadioButton()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblTotalCal = New System.Windows.Forms.Label()
        Me.lblAmountDisplay = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblEnterDays = New System.Windows.Forms.Label()
        Me.txtNumberOfDays = New System.Windows.Forms.TextBox()
        Me.lstDisplay = New System.Windows.Forms.ListView()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'radPenny
        '
        Me.radPenny.AutoSize = True
        Me.radPenny.Location = New System.Drawing.Point(172, 75)
        Me.radPenny.Name = "radPenny"
        Me.radPenny.Size = New System.Drawing.Size(55, 17)
        Me.radPenny.TabIndex = 0
        Me.radPenny.TabStop = True
        Me.radPenny.Text = "Penny"
        Me.radPenny.UseVisualStyleBackColor = True
        '
        'radNickel
        '
        Me.radNickel.AutoSize = True
        Me.radNickel.Location = New System.Drawing.Point(283, 75)
        Me.radNickel.Name = "radNickel"
        Me.radNickel.Size = New System.Drawing.Size(55, 17)
        Me.radNickel.TabIndex = 1
        Me.radNickel.TabStop = True
        Me.radNickel.Text = "Nickel"
        Me.radNickel.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(480, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClear, Me.mnuExit})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'mnuClear
        '
        Me.mnuClear.Name = "mnuClear"
        Me.mnuClear.Size = New System.Drawing.Size(101, 22)
        Me.mnuClear.Text = "&Clear"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(101, 22)
        Me.mnuExit.Text = "E&xit"
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(198, 33)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(100, 13)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = "Pay Day Calculator "
        '
        'lblTotalCal
        '
        Me.lblTotalCal.AutoSize = True
        Me.lblTotalCal.Location = New System.Drawing.Point(33, 200)
        Me.lblTotalCal.Name = "lblTotalCal"
        Me.lblTotalCal.Size = New System.Drawing.Size(109, 13)
        Me.lblTotalCal.TabIndex = 6
        Me.lblTotalCal.Text = "Here is your total pay "
        '
        'lblAmountDisplay
        '
        Me.lblAmountDisplay.AutoSize = True
        Me.lblAmountDisplay.Location = New System.Drawing.Point(198, 200)
        Me.lblAmountDisplay.Name = "lblAmountDisplay"
        Me.lblAmountDisplay.Size = New System.Drawing.Size(0, 13)
        Me.lblAmountDisplay.TabIndex = 7
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(201, 166)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 8
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'lblEnterDays
        '
        Me.lblEnterDays.AutoSize = True
        Me.lblEnterDays.Location = New System.Drawing.Point(33, 115)
        Me.lblEnterDays.Name = "lblEnterDays"
        Me.lblEnterDays.Size = New System.Drawing.Size(179, 13)
        Me.lblEnterDays.TabIndex = 9
        Me.lblEnterDays.Text = "Please enter number of days worked"
        '
        'txtNumberOfDays
        '
        Me.txtNumberOfDays.Location = New System.Drawing.Point(238, 112)
        Me.txtNumberOfDays.Name = "txtNumberOfDays"
        Me.txtNumberOfDays.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberOfDays.TabIndex = 10
        '
        'lstDisplay
        '
        Me.lstDisplay.Location = New System.Drawing.Point(359, 75)
        Me.lstDisplay.Name = "lstDisplay"
        Me.lstDisplay.Size = New System.Drawing.Size(121, 97)
        Me.lstDisplay.TabIndex = 11
        Me.lstDisplay.UseCompatibleStateImageBehavior = False
        '
        'frmPayDay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 238)
        Me.Controls.Add(Me.lstDisplay)
        Me.Controls.Add(Me.txtNumberOfDays)
        Me.Controls.Add(Me.lblEnterDays)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblAmountDisplay)
        Me.Controls.Add(Me.lblTotalCal)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.radNickel)
        Me.Controls.Add(Me.radPenny)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmPayDay"
        Me.Text = "Pay Day"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents radPenny As RadioButton
    Friend WithEvents radNickel As RadioButton
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mnuClear As ToolStripMenuItem
    Friend WithEvents mnuExit As ToolStripMenuItem
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblTotalCal As Label
    Friend WithEvents lblAmountDisplay As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblEnterDays As Label
    Friend WithEvents txtNumberOfDays As TextBox
    Friend WithEvents lstDisplay As ListView
End Class
