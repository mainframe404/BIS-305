﻿' Program Name: Commuter Cost Calculator 
' Author:       Allyson Frame
' Date:         October 24, 2017
' Purpose:      Calculates total yearly cost of commuting to work

Public Class frmCostCalculator

    'class vars
    Private _intTotalMonth As Integer = 12

    'using to troubleshoot
    Private intTravelChoice = -1

    Private Sub cboTravel_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTravel.SelectedIndexChanged, cboTravel.SelectedIndexChanged
        ' This event handler allows the user to enter the travel choice and then calls subprocedures to ask the user questions. 

        intTravelChoice = cboTravel.SelectedIndex
        Select Case intTravelChoice
            Case 0
                carCommute()
            Case 1
                trainCommute()
            Case 2
                busCommute()
        End Select
        'btnClear.Visible = True
        btnFindCost.Visible = True
        lblTravel.Visible = False
    End Sub

    Private Sub carCommute()
        'This makes questions visable when Car is selected. 

        lbltripDistance.Visible = True
        txtTripDistance.Visible = True

        lblDaysWorked.Visible = True
        txtDaysWorked.Visible = True

        lblMiles.Visible = True
        txtMiles.Visible = True

        lblGasCost.Visible = True
        txtGallonCost.Visible = True

        lblMonthlyCostMaint.Visible = True
        txtMonthlyCostMaint.Visible = True

        lblParking.Visible = True
        txtParking.Visible = True

        lblRoundTripFair.Visible = False
        txtRoundTripFair.Visible = False

        lblTotal.Visible = False
        lblFinal.Visible = False
    End Sub

    Private Sub trainCommute()
        'This makes questions visable when Train is selected.
        lblRoundTripFair.Visible = True
        txtRoundTripFair.Visible = True

        lblDaysWorked.Visible = True
        txtDaysWorked.Visible = True
    End Sub

    Private Sub busCommute()
        'This makes questions visable when Bus is selected.
        lblRoundTripFair.Visible = True
        txtRoundTripFair.Visible = True

        lblDaysWorked.Visible = True
        txtDaysWorked.Visible = True
    End Sub


    Private Sub btnFindCost_Click(sender As Object, e As EventArgs) Handles btnFindCost.Click
        'Determins yearly cost of commute 
        'Not sure if nested cases where the correct way to go but it works

        Dim decTotalCost As Decimal

        Select Case intTravelChoice
            Case 0
                If (VaildateNumberInDaysWorked() And VaildateNumberInTripDistance() And VaildateNumberInMiles() And VaildateNumberInMonthlyCostMaint() And VaildateNumberInGallonCost() And VaildateNumberInParking()) Then
                    decTotalCost = CarFindCost()
                End If
            Case 1
                If (VaildateNumberInDaysWorked() And VaildateNumberInRoundTripFair()) Then
                    decTotalCost = TrainFindCost()
                End If
            Case 2
                If (VaildateNumberInDaysWorked() And VaildateNumberInRoundTripFair()) Then
                    decTotalCost = BusFindCost()
                End If
        End Select

        lblTotal.Visible = True
        lblFinal.Text = decTotalCost
        lblFinal.Visible = True
    End Sub

    Private Function VaildateNumberInDaysWorked() As Boolean
        'this checks to make sure days worked has vaild number

        Dim intDaysWorked As Integer
        Dim blnValidityCheckDaysWorked As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the number of days worked per a month"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intDaysWorked = Convert.ToInt32(txtDaysWorked.Text)
            If intDaysWorked >= 0 Then
                blnValidityCheckDaysWorked = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtDaysWorked.Focus()
                txtDaysWorked.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtDaysWorked.Focus()
            txtDaysWorked.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtDaysWorked.Focus()
            txtDaysWorked.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtDaysWorked.Focus()
            txtDaysWorked.Clear()
        End Try

        Return blnValidityCheckDaysWorked

    End Function

    Private Function VaildateNumberInTripDistance() As Boolean
        'this checks to make sure Trip Distance has vaild number

        Dim intTripDistance As Decimal
        Dim blnValidityCheckTripDistance As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the Daily Round Trip Distance"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intTripDistance = Convert.ToDecimal(txtTripDistance.Text)
            If intTripDistance >= 0 Then
                blnValidityCheckTripDistance = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtTripDistance.Focus()
                txtTripDistance.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTripDistance.Focus()
            txtTripDistance.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTripDistance.Focus()
            txtTripDistance.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtTripDistance.Focus()
            txtTripDistance.Clear()
        End Try

        Return blnValidityCheckTripDistance

    End Function

    Private Function VaildateNumberInMiles() As Boolean
        'this checks to make sure Miles Per Gallon has vaild number

        Dim intMiles As Decimal
        Dim blnValidityCheckMiles As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the Miles Per Gallon"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intMiles = Convert.ToDecimal(txtMiles.Text)
            If intMiles >= 0 Then
                blnValidityCheckMiles = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtMiles.Focus()
                txtMiles.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtMiles.Focus()
            txtMiles.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtMiles.Focus()
            txtMiles.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtMiles.Focus()
            txtMiles.Clear()
        End Try

        Return blnValidityCheckMiles

    End Function

    Private Function VaildateNumberInGallonCost() As Boolean
        'this checks to make sure Cost per gallon of gas has vaild number

        Dim intGallonCost As Decimal
        Dim blnValidityCheckGallonCost As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the Cost Per Gallon of Gas"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intGallonCost = Convert.ToDecimal(txtGallonCost.Text)
            If intGallonCost >= 0 Then
                blnValidityCheckGallonCost = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtGallonCost.Focus()
                txtGallonCost.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtGallonCost.Focus()
            txtGallonCost.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtGallonCost.Focus()
            txtGallonCost.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtGallonCost.Focus()
            txtGallonCost.Clear()
        End Try

        Return blnValidityCheckGallonCost

    End Function

    Private Function VaildateNumberInMonthlyCostMaint() As Boolean
        'this checks to make sure Monthly Cost of Maintence and Insurence has vaild number

        Dim intMonthlyCostMaint As Decimal
        Dim blnValidityCheckMonthlyCostMaint As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the Monthly Cost of Maintence and Insurence"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intMonthlyCostMaint = Convert.ToDecimal(txtMonthlyCostMaint.Text)
            If intMonthlyCostMaint >= 0 Then
                blnValidityCheckMonthlyCostMaint = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtMonthlyCostMaint.Focus()
                txtMonthlyCostMaint.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtMonthlyCostMaint.Focus()
            txtMonthlyCostMaint.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtMonthlyCostMaint.Focus()
            txtMonthlyCostMaint.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtMonthlyCostMaint.Focus()
            txtMonthlyCostMaint.Clear()
        End Try

        Return blnValidityCheckMonthlyCostMaint

    End Function

    Private Function VaildateNumberInParking() As Boolean
        'this checks to make sure monthly parking has vaild number

        Dim intParking As Decimal
        Dim blnValidityCheckParking As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the Monthly Cost of Parking"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intParking = Convert.ToDecimal(txtParking.Text)
            If intParking >= 0 Then
                blnValidityCheckParking = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtParking.Focus()
                txtParking.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtParking.Focus()
            txtParking.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtParking.Focus()
            txtParking.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtParking.Focus()
            txtParking.Clear()
        End Try

        Return blnValidityCheckParking

    End Function

    Private Function VaildateNumberInRoundTripFair() As Boolean
        'this checks to make sure Round Trip Fair has vaild number

        Dim intRoundTripFair As Decimal
        Dim blnValidityCheckRoundTripFair As Boolean = False
        Dim strNumberInTeamMessage As String = "Please enter the Cost of Round Trip Fair"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intRoundTripFair = Convert.ToDecimal(txtRoundTripFair.Text)
            If intRoundTripFair >= 0 Then
                blnValidityCheckRoundTripFair = True
            Else
                MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
                txtRoundTripFair.Focus()
                txtRoundTripFair.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtRoundTripFair.Focus()
            txtRoundTripFair.Clear()
        Catch Exception As OverflowException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtRoundTripFair.Focus()
            txtRoundTripFair.Clear()
        Catch Exception As SystemException
            MsgBox(strNumberInTeamMessage, , strMessageBoxTitle)
            txtRoundTripFair.Focus()
            txtRoundTripFair.Clear()
        End Try

        Return blnValidityCheckRoundTripFair

    End Function

    Private Function CarFindCost() As Decimal
        'Finds cost of yearly commute for Car

        Dim decFinalCost As Decimal
        Dim intDaysWorked As Integer
        Dim decTripDistance As Decimal
        Dim decMiles As Decimal
        Dim decGallonCost As Decimal
        Dim decGasCost As Decimal
        Dim decTotalGasCost As Decimal
        Dim decMonthlyCostMaint As Decimal
        Dim decTotalMonthlyCostMaint As Decimal
        Dim decParking As Decimal
        Dim decTotalParking As Decimal

        intDaysWorked = Convert.ToInt32(txtDaysWorked.Text)
        decTripDistance = Convert.ToDecimal(txtTripDistance.Text)
        decMiles = Convert.ToDecimal(txtMiles.Text)
        decGallonCost = Convert.ToDecimal(txtGallonCost.Text)
        decMonthlyCostMaint = Convert.ToInt32(txtMonthlyCostMaint.Text)
        decParking = Convert.ToDecimal(txtParking.Text)

        'Calculates total gas cost for year
        decGasCost = (decTripDistance / decMiles) * decGallonCost
        decTotalGasCost = (decGasCost * intDaysWorked) * _intTotalMonth

        'Calculates total Mainence for year
        decTotalMonthlyCostMaint = decMonthlyCostMaint * _intTotalMonth

        'Calculates total parking for year
        decTotalParking = decParking * _intTotalMonth

        decFinalCost = decTotalGasCost + decTotalMonthlyCostMaint + decTotalParking

        Return decFinalCost

    End Function

    Private Function TrainFindCost() As Decimal
        'Finds cost of yearly commute for Bus

        Dim decFinalCost As Decimal
        Dim intDaysWorked As Integer
        Dim decRoundTripFair As Decimal

        intDaysWorked = Convert.ToInt32(txtDaysWorked.Text)
        decRoundTripFair = Convert.ToDecimal(txtRoundTripFair.Text)

        decFinalCost = (intDaysWorked * decRoundTripFair) * _intTotalMonth


        Return decFinalCost

    End Function

    Private Function BusFindCost() As Decimal
        'Finds cost of yearly commute for Bus

        Dim decFinalCost As Decimal
        Dim intDaysWorked As Integer
        Dim decRoundTripFair As Decimal

        intDaysWorked = Convert.ToInt32(txtDaysWorked.Text)
        decRoundTripFair = Convert.ToDecimal(txtRoundTripFair.Text)

        decFinalCost = (intDaysWorked * decRoundTripFair) * _intTotalMonth


        Return decFinalCost

    End Function



    'Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
    '    ' This event handler clears the form and resets the form for reuse when the user clicks the Clear button.

    '    'thoght this would be good to have just in case
    '    cboTravel.Text = "Select Travel Type"

    '    'Clears out all the txt boxes when user hits clear
    '    txtTripDistance.Clear()
    '    txtDaysWorked.Clear()
    '    txtMiles.Clear()
    '    txtGallonCost.Clear()
    '    txtGallonCost.Clear()
    '    txtMonthlyCostMaint.Clear()
    '    txtParking.Clear()
    '    txtRoundTripFair.Clear()

    '    btnClear.Visible = False
    '    btnFindCost.Visible = False

    '    lbltripDistance.Visible = False
    '    txtTripDistance.Visible = False

    '    lblDaysWorked.Visible = False
    '    txtDaysWorked.Visible = False

    '    lblMiles.Visible = False
    '    txtMiles.Visible = False

    '    lblGasCost.Visible = False
    '    txtGallonCost.Visible = False

    '    lblMonthlyCostMaint.Visible = False
    '    txtMonthlyCostMaint.Visible = False

    '    lblParking.Visible = False
    '    txtParking.Visible = False

    '    lblRoundTripFair.Visible = False
    '    txtRoundTripFair.Visible = False

    '    lblTotal.Visible = False
    '    lblFinal.Visible = False

    '    lblTravel.Visible = True
    'End Sub


    Private Sub frmCostCalculator_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Hold the splash screen for 5 seconds
        Threading.Thread.Sleep(5000)

        'These make the questions not visable to the user untill they select transportation mode
        lblTravel.Visible = True

        btnClear.Visible = False
        btnFindCost.Visible = False

        lbltripDistance.Visible = False
        txtTripDistance.Visible = False

        lblDaysWorked.Visible = False
        txtDaysWorked.Visible = False

        lblMiles.Visible = False
        txtMiles.Visible = False

        lblGasCost.Visible = False
        txtGallonCost.Visible = False

        lblMonthlyCostMaint.Visible = False
        txtMonthlyCostMaint.Visible = False

        lblParking.Visible = False
        txtParking.Visible = False

        lblRoundTripFair.Visible = False
        txtRoundTripFair.Visible = False

        lblTotal.Visible = False
        lblFinal.Visible = False
    End Sub

End Class
