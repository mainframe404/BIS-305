﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCostCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.cboTravel = New System.Windows.Forms.ComboBox()
        Me.lbltripDistance = New System.Windows.Forms.Label()
        Me.lblDaysWorked = New System.Windows.Forms.Label()
        Me.lblMiles = New System.Windows.Forms.Label()
        Me.lblMonthlyCostMaint = New System.Windows.Forms.Label()
        Me.lblParking = New System.Windows.Forms.Label()
        Me.txtTripDistance = New System.Windows.Forms.TextBox()
        Me.txtDaysWorked = New System.Windows.Forms.TextBox()
        Me.txtMiles = New System.Windows.Forms.TextBox()
        Me.txtMonthlyCostMaint = New System.Windows.Forms.TextBox()
        Me.txtParking = New System.Windows.Forms.TextBox()
        Me.btnFindCost = New System.Windows.Forms.Button()
        Me.txtRoundTripFair = New System.Windows.Forms.TextBox()
        Me.lblRoundTripFair = New System.Windows.Forms.Label()
        Me.lblGasCost = New System.Windows.Forms.Label()
        Me.txtGallonCost = New System.Windows.Forms.TextBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblFinal = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblTravel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cboTravel
        '
        Me.cboTravel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboTravel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTravel.FormattingEnabled = True
        Me.cboTravel.Items.AddRange(New Object() {"Car", "Train", "Bus"})
        Me.cboTravel.Location = New System.Drawing.Point(298, 18)
        Me.cboTravel.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.cboTravel.Name = "cboTravel"
        Me.cboTravel.Size = New System.Drawing.Size(219, 28)
        Me.cboTravel.TabIndex = 0
        '
        'lbltripDistance
        '
        Me.lbltripDistance.AutoSize = True
        Me.lbltripDistance.Location = New System.Drawing.Point(69, 86)
        Me.lbltripDistance.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbltripDistance.Name = "lbltripDistance"
        Me.lbltripDistance.Size = New System.Drawing.Size(154, 20)
        Me.lbltripDistance.TabIndex = 1
        Me.lbltripDistance.Text = "Round Trip Distance"
        '
        'lblDaysWorked
        '
        Me.lblDaysWorked.AutoSize = True
        Me.lblDaysWorked.Location = New System.Drawing.Point(69, 134)
        Me.lblDaysWorked.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDaysWorked.Name = "lblDaysWorked"
        Me.lblDaysWorked.Size = New System.Drawing.Size(176, 20)
        Me.lblDaysWorked.TabIndex = 2
        Me.lblDaysWorked.Text = "Days worked per month"
        '
        'lblMiles
        '
        Me.lblMiles.AutoSize = True
        Me.lblMiles.Location = New System.Drawing.Point(69, 178)
        Me.lblMiles.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMiles.Name = "lblMiles"
        Me.lblMiles.Size = New System.Drawing.Size(137, 20)
        Me.lblMiles.TabIndex = 3
        Me.lblMiles.Text = "Mileage per gallon"
        '
        'lblMonthlyCostMaint
        '
        Me.lblMonthlyCostMaint.AutoSize = True
        Me.lblMonthlyCostMaint.Location = New System.Drawing.Point(69, 279)
        Me.lblMonthlyCostMaint.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblMonthlyCostMaint.Name = "lblMonthlyCostMaint"
        Me.lblMonthlyCostMaint.Size = New System.Drawing.Size(303, 20)
        Me.lblMonthlyCostMaint.TabIndex = 4
        Me.lblMonthlyCostMaint.Text = "Monthly Cost of Maintence and Insurence"
        '
        'lblParking
        '
        Me.lblParking.AutoSize = True
        Me.lblParking.Location = New System.Drawing.Point(69, 342)
        Me.lblParking.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblParking.Name = "lblParking"
        Me.lblParking.Size = New System.Drawing.Size(176, 20)
        Me.lblParking.TabIndex = 5
        Me.lblParking.Text = "Monthly Cost of Parking"
        '
        'txtTripDistance
        '
        Me.txtTripDistance.Location = New System.Drawing.Point(264, 86)
        Me.txtTripDistance.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtTripDistance.Name = "txtTripDistance"
        Me.txtTripDistance.Size = New System.Drawing.Size(109, 26)
        Me.txtTripDistance.TabIndex = 6
        '
        'txtDaysWorked
        '
        Me.txtDaysWorked.Location = New System.Drawing.Point(264, 129)
        Me.txtDaysWorked.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtDaysWorked.Name = "txtDaysWorked"
        Me.txtDaysWorked.Size = New System.Drawing.Size(148, 26)
        Me.txtDaysWorked.TabIndex = 7
        '
        'txtMiles
        '
        Me.txtMiles.Location = New System.Drawing.Point(264, 181)
        Me.txtMiles.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtMiles.Name = "txtMiles"
        Me.txtMiles.Size = New System.Drawing.Size(148, 26)
        Me.txtMiles.TabIndex = 8
        '
        'txtMonthlyCostMaint
        '
        Me.txtMonthlyCostMaint.Location = New System.Drawing.Point(395, 291)
        Me.txtMonthlyCostMaint.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtMonthlyCostMaint.Name = "txtMonthlyCostMaint"
        Me.txtMonthlyCostMaint.Size = New System.Drawing.Size(148, 26)
        Me.txtMonthlyCostMaint.TabIndex = 9
        '
        'txtParking
        '
        Me.txtParking.Location = New System.Drawing.Point(266, 342)
        Me.txtParking.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtParking.Name = "txtParking"
        Me.txtParking.Size = New System.Drawing.Size(148, 26)
        Me.txtParking.TabIndex = 10
        '
        'btnFindCost
        '
        Me.btnFindCost.Location = New System.Drawing.Point(159, 505)
        Me.btnFindCost.Name = "btnFindCost"
        Me.btnFindCost.Size = New System.Drawing.Size(133, 35)
        Me.btnFindCost.TabIndex = 11
        Me.btnFindCost.Text = "Find Cost"
        Me.btnFindCost.UseVisualStyleBackColor = True
        '
        'txtRoundTripFair
        '
        Me.txtRoundTripFair.Location = New System.Drawing.Point(264, 86)
        Me.txtRoundTripFair.Name = "txtRoundTripFair"
        Me.txtRoundTripFair.Size = New System.Drawing.Size(100, 26)
        Me.txtRoundTripFair.TabIndex = 12
        '
        'lblRoundTripFair
        '
        Me.lblRoundTripFair.AutoSize = True
        Me.lblRoundTripFair.Location = New System.Drawing.Point(69, 91)
        Me.lblRoundTripFair.Name = "lblRoundTripFair"
        Me.lblRoundTripFair.Size = New System.Drawing.Size(161, 20)
        Me.lblRoundTripFair.TabIndex = 14
        Me.lblRoundTripFair.Text = "Round Trip Trasit Fair"
        '
        'lblGasCost
        '
        Me.lblGasCost.AutoSize = True
        Me.lblGasCost.Location = New System.Drawing.Point(69, 230)
        Me.lblGasCost.Name = "lblGasCost"
        Me.lblGasCost.Size = New System.Drawing.Size(163, 20)
        Me.lblGasCost.TabIndex = 15
        Me.lblGasCost.Text = "Cost per gallon of gas"
        '
        'txtGallonCost
        '
        Me.txtGallonCost.Location = New System.Drawing.Point(273, 230)
        Me.txtGallonCost.Name = "txtGallonCost"
        Me.txtGallonCost.Size = New System.Drawing.Size(100, 26)
        Me.txtGallonCost.TabIndex = 16
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(73, 412)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(271, 20)
        Me.lblTotal.TabIndex = 17
        Me.lblTotal.Text = "Total Cost Of Commuting for the year"
        '
        'lblFinal
        '
        Me.lblFinal.AutoSize = True
        Me.lblFinal.Location = New System.Drawing.Point(428, 411)
        Me.lblFinal.Name = "lblFinal"
        Me.lblFinal.Size = New System.Drawing.Size(0, 20)
        Me.lblFinal.TabIndex = 18
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(395, 505)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(122, 35)
        Me.btnClear.TabIndex = 19
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblTravel
        '
        Me.lblTravel.AutoSize = True
        Me.lblTravel.Location = New System.Drawing.Point(96, 21)
        Me.lblTravel.Name = "lblTravel"
        Me.lblTravel.Size = New System.Drawing.Size(171, 20)
        Me.lblTravel.TabIndex = 20
        Me.lblTravel.Text = "How do you commute?"
        '
        'frmCostCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(721, 558)
        Me.Controls.Add(Me.lblTravel)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblFinal)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.txtGallonCost)
        Me.Controls.Add(Me.lblGasCost)
        Me.Controls.Add(Me.lblRoundTripFair)
        Me.Controls.Add(Me.txtRoundTripFair)
        Me.Controls.Add(Me.btnFindCost)
        Me.Controls.Add(Me.txtParking)
        Me.Controls.Add(Me.txtMonthlyCostMaint)
        Me.Controls.Add(Me.txtMiles)
        Me.Controls.Add(Me.txtDaysWorked)
        Me.Controls.Add(Me.txtTripDistance)
        Me.Controls.Add(Me.lblParking)
        Me.Controls.Add(Me.lblMonthlyCostMaint)
        Me.Controls.Add(Me.lblMiles)
        Me.Controls.Add(Me.lblDaysWorked)
        Me.Controls.Add(Me.lbltripDistance)
        Me.Controls.Add(Me.cboTravel)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmCostCalculator"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboTravel As ComboBox
    Friend WithEvents lbltripDistance As Label
    Friend WithEvents lblDaysWorked As Label
    Friend WithEvents lblMiles As Label
    Friend WithEvents lblMonthlyCostMaint As Label
    Friend WithEvents lblParking As Label
    Friend WithEvents txtTripDistance As TextBox
    Friend WithEvents txtDaysWorked As TextBox
    Friend WithEvents txtMiles As TextBox
    Friend WithEvents txtMonthlyCostMaint As TextBox
    Friend WithEvents txtParking As TextBox
    Friend WithEvents btnFindCost As Button
    Friend WithEvents txtRoundTripFair As TextBox
    Friend WithEvents lblRoundTripFair As Label
    Friend WithEvents lblGasCost As Label
    Friend WithEvents txtGallonCost As TextBox
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblFinal As Label
    Friend WithEvents btnClear As Button
    Friend WithEvents lblTravel As Label
End Class
